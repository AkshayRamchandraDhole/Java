class Program3{

	public static void main(String[] args){
	
		StringBuffer sb1 = new StringBuffer("Good");
		System.out.println("Before Append : "+sb1);
		sb1.append("Life");
		System.out.println("After Append : "+sb1);
	}
}
