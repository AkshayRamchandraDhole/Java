class Program1{

	public static void main(String args[]){
	
		char ch='K';
		if((ch>='A' && ch<='Z') || (ch>='a' && ch<='z'))
			System.out.println(ch+" is a alphabet");
		else
			System.out.println(ch+" is not a alphabet");
			
	}
}
