class Program2{

	public static void main(String args[]){
	
		char ch='O';
		if(ch=='A' || ch=='a' || ch=='e' || ch=='E' || ch=='i' || ch=='I' || ch=='o' || ch=='O' || ch=='u' || ch=='U')
			System.out.println(ch+" is vowel");
		else
			System.out.println(ch+" is consonant");
			
	}
}
