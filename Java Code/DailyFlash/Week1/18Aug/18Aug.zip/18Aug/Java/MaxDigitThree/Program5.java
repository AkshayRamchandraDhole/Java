class Program5{

	public static void main(String args[]){
	
		int a=10,b=27,c=18;
		String ans=(a > b) ? (a > c) ? "A is Greater":"C is Greater": (b > c) ? " B is Greater": " C is Greater";
		System.out.println(ans);
			
	}
}
