class Demo{
	public static void main(String[] args){
		int n = 1;
		for(int i = 0; i < 4; i++){
			for(int j = 0; j < 4; j++){
				System.out.print(n + "\t\t");
				n++;
			}	
			System.out.println();
		}		
	}
}
