class Program1{

	public static void main(String arsg[]){
	
		double dRad = 5;
		double dArea = 3.14 * dRad * dRad;
		System.out.println("Area of Circle:"+dArea);
	}
}
