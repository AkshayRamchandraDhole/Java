class Program2{

	public static void main(String args[]){
	
		int iNum1=0;
		if(iNum1 < 0)
			System.out.println(iNum1+" is negative number");
		else if(iNum1==0)
			System.out.println(iNum1+" is zero number");
		else
			System.out.println(iNum1+" is positive number");

	}
}
