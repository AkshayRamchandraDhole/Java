class Program3{

	public static void main(String args[]){
	
		int iNum1=7;
		if(iNum1 % 2 == 0)
			System.out.println(iNum1+" is Even number");
		else
			System.out.println(iNum1+" is odd number");

	}
}
