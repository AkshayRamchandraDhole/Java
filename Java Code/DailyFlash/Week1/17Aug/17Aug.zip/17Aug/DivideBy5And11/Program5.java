class Program5{

	public static void main(String args[]){
	
		int iNum1=55;
		if(iNum1 % 5 == 0 && iNum1 % 11 == 0)
			System.out.println(iNum1+" is divide by 5 & 11");
		else
			System.out.println(iNum1+" is not divide by 5 & 11");

	}
}
