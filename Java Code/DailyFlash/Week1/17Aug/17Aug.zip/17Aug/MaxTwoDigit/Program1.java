class Program1{

	public static void main(String args[]){
	
		int iNum1=10,iNum2=7;
		if(iNum1 > iNum2)
			System.out.println(iNum1+" is Max number among "+iNum1+" & "+iNum2);
		else
			System.out.println(iNum2+" is Max number among "+iNum1+" & "+iNum2);

	}
}
