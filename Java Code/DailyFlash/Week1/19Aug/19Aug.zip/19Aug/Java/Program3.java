class Program3{

	public static void main(String args[]){
	
		int iNum=15;
		switch(iNum){
		
			case 0:
				System.out.println("In Jan 31 Days..");
			break;
			case 1:
				System.out.println("In Feb 28/29 Days..");
			break;
			case 2:
				System.out.println("In Mar 31 Days..");
			break;
			case 3:
				System.out.println("In Apr 30 Days..");
			break;
			case 4:
				System.out.println("In May 31 Days..");
			break;
			case 5:
				System.out.println("In Jun 30 Days..");
			break;
			case 6:
				System.out.println("In Jul 31 Days..");
			break;
			case 7:
				System.out.println("In Aug 31 Days..");
			break;
			case 8:
				System.out.println("In Sep 30 Days..");
			break;
			case 9:
				System.out.println("In Oct 31 Days..");
			break;
			case 10:
				System.out.println("In Nov 30 Days..");
			break;
			case 11:
				System.out.println("In Dec 31 Days..");
			break;

			default:
				System.out.println("Invalid Month..");
			break;
		}
	}
}
