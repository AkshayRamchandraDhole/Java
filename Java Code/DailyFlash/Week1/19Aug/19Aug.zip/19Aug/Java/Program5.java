class Program5{

	public static void main(String args[]){
	
		int a=30,b=60,c=90;
		int total=a+b+c;
		if(total==180)
			System.out.println("This is triangle");
		else
			System.out.println("This is not triangle");
	}
}
