class Check{

	public static void main(String[] args){
	
		System.out.println("Main with Argument...");
		Check ch = new Check();
		ch.main();
	}
	public static void main(){
	
		System.out.println("Main() without Argument..");
	}
}
