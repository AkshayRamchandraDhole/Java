class Program5{

	public static void main(String ...args){
	
		int iNum1 = Integer.parseInt(args[0]);
		int iNum2 = Integer.parseInt(args[1]);
		System.out.println("The sum of "+iNum1+" & "+iNum2+" is "+(iNum1+iNum2));
	}
}
