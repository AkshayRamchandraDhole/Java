class Program5{

	public static void main(String[] args){
	
		char[] ch={'A','B','C','D','E','F'};
		for(int i=0;i<ch.length;i++){
		
			for(int j=0;j<=i;j++){
			
				System.out.print(ch[j]+" ");
			}
			System.out.println();
		}

	}
}
