class Program5{

	public static void main(String[] args){
	
		StringBuffer sb1 = new StringBuffer("Core2Web");
		System.out.println(sb1);
		sb1.append("Technologies");
		System.out.println(sb1);
	}
}
