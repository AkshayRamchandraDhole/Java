class Program1{

	public static void main(String[] args){
	
		byte[] arr = new byte[]{94,97,27,24,65,66,67,68,69,94,97,22,23};
		String st = new String(arr);
		System.out.println(st);
	}
}
