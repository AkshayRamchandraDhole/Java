class Program2{

	public static void main(String[] args){
	
		int[] arr1 = {10,13,55,78,90};
		for(int i=0;i<5;i++){
`:
			if(arr1[i] % 2 ==0)
				System.out.println("Even Number are: "+arr1[i]);
		}
	}
}
