class Program5{

	public static void main(String[] args){
	
		char[] carr = {'A','B','C','D','E'};
		for(int i=0;i<5;i++){
			System.out.print((char)(carr[i]+32)+" ");
		}
		System.out.println();
	}
}
