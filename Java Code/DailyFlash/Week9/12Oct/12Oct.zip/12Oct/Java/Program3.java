class Program3{

	public static void main(String[] args){
	
		String s1="RCB";
		String s2 = new String("SRH");
		System.out.println(s1+" "+s2);

		// String s1 = "RCB";   Store in SCP with reference
		// String s2 = new String("SRH"); Store on heap with refernce and without reference on SCP (String Constant Pool)
	}
}
