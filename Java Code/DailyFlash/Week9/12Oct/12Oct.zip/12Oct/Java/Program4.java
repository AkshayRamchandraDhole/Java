class Program4{

	public static void main(String[] args){
	
		String s1="KXIP";
		String s2 = new String("KKR");
		System.out.println("String Before operation : "+s1+" "+s2);
		s1=new String("KKR");
		s2="KXIP";
		System.out.println("String After operation : "+s1+" "+s2);
	}
}
