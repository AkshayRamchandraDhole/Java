import java.util.*;
class Program2{

	public static void main(String[] args){
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String1 : ");
		String s1=sc.next();
		System.out.println("Enter String2 : ");
		String s2=sc.next();
		System.out.println("''"+s1+"''"+" ''"+s2+"''");
	}
}
