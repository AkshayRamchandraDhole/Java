class Program1{

	public static void main(String[] args){
	
		String s1="MI";
		String s2 = new String("DC");
		System.out.println(s1+" "+s2);
	}
}
