/*
Program 1: Write a program to print First 10 Natural Numbers.
Output: 1 2 3 4 5 6 8 9 10

*/

class NaturalNumber{
	
	public static void main(String args[]){
		
		System.out.println("First 10 Natural Numbers");
		for(int itr = 1 ; itr <= 10 ; itr++ ){

			System.out.printf("%d ",itr);
		}
	}	

}	
