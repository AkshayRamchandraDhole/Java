class Program2{

	public static void main(String args[]){
	
		int iSum=0;
		System.out.println("Natural Number from 1 to 10:");
		for(int i=1;i<=10;i++){
		
			System.out.println(i);
			iSum+=i;
		}
		System.out.println("Sum of First 10 Natural is:"+iSum);
	}
}
