class Program2{

	int a=10;
	String nm="Akshay";
	boolean val=true;
	Program2(){
	
		System.out.println("In Default Constructor");
		System.out.println("A : "+a);
		System.out.println("Name : "+nm);
		System.out.println("Value : "+val);
	
	}

	public static void main(String[] args){

		Program1 p = new Program1();

	}
}
