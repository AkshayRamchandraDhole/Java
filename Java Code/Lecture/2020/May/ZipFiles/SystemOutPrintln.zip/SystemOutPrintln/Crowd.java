class Crowd{

	public static void main(String args[]){
	
		BCCI.i.emergingPlayer();
	}
}
