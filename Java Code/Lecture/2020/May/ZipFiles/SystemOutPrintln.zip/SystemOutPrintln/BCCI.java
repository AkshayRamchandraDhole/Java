class BCCI{
	//static int a=10;
	//static IPL i=new IPL();

	void impDecision(){
	
		System.out.println("Decision");
	}

	/*public static void main(String args[]){
	
		//BCCI b=new BCCI();
		//b.impDecision();
		System.out.println(a);
		IPL i=new IPL();
		i.emergingPlayer();
	}*/
}
