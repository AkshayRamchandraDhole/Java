class IPL{

	void emergingPlayer(){
	
		System.out.println("Young Player");
		//BCCI b=new BCCI();
		//b.impDecision();  // Decision
	
		//System.out.println(BCCI.a);//  10

		//BCCI.impDecision(); error: non-static method impDecision() cannot be referenced from a static context
	}

}
