class KHome{

	int i=10;

	void calling(){
	
		System.out.println("Call krt ahe...");
		//System.out.println(AHome.mom);
		//AHome a=new AHome();
		//a.laptopUse();
	}

/*	public static void main(String args[]){
	
		KHome k=new KHome();
		k.calling();
	}*/
}
