class Phone{

	public static void main(String args[]){
	
		AHome.k.calling();
		System.out.println(AHome.k.i);
	//	AHome a=new AHome();
	//	a.laptopUse();
	}
}
