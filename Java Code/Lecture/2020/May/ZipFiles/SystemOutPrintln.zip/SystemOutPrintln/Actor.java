//By Deafault 
import java.lang.*;

// class Actor extends Object
class Actor{

	public static void main(String args[]){
	
		System.out.println("Hrithik Roshan");
		System.out.println("Irfan Khan");
		movies();
	}

	static void movies(){
	
		
		System.out.println("Bang Bang");
		System.out.println("Hindi Medium");
	}


}
