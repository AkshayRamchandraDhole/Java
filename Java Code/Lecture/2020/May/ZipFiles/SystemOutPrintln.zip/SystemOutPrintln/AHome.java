class AHome{
	//static String mom="Sharda";
	static KHome k=new KHome();

	void laptopUse(){
	
		System.out.println("Laptop Use Karne....");
		//KHome k=new KHome();
		//k.calling();
	}

/*	public static void main(String args[]){
	
		AHome a=new AHome();
		a.laptopUse();
		KHome k=new KHome();
		k.calling();
	}*/
}
