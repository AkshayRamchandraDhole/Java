class Player{

static	void info(){
	
		System.out.println("Batsman");
	}

	public static void main(String args[]){
	
		Player p=new Player();
		System.out.println("Virat Kohli");
		info();
	}
}
