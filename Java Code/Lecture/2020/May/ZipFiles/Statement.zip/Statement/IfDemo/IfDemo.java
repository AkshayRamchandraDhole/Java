class IfDemo{

	public static void main(String args[]){
		
		int n1=10;
		int n2=17,n3=7;
		if(!(n1==10))
			System.out.println("Akshay");
	}
}
