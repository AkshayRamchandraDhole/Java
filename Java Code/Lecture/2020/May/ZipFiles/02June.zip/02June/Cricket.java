class Cricket{
	
	Cricket(){
		//super()
		System.out.println("In Constructor...");
	}

	public static void main(String args[]){
	
	Cricket c=new Cricket();	
	System.out.println("In main...");

	}
}
