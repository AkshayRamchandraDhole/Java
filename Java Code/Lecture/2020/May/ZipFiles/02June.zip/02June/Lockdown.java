/*	By default konatya ghosti yetat :
 *					1) import java.lang.*;
 *					2) extends Object class
 *					3) Constructor
 *						super() //Object
 */
class Lockdown  {   //Object

	/*  constructor 
	 *  Lockdown(){
	 *	super();   // Object      Object{
	 *						return;
	 *					}
	 *	return;
	 *  }
	 *
	 * */

	public static void main(String args[]){
	
		System.out.println("Lockdown extends....");
	
	}

}
