class Home{

	int tv=0;

	/* Constructor
	 *
	 * Home(){
	 *	super(); // Object
	 *	tv=0
	 * }
	 * */

	public static void main(String args[]){
	
		Home h=new Home();
		System.out.println("In main..");
	}
}
