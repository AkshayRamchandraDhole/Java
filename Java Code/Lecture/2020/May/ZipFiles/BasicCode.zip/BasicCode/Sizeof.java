class Size{

	public static void main(String args[]){
	
		System.out.println("Byte Size in bits:"+Byte.SIZE);
		System.out.println("Byte Size in Bytes:"+Byte.BYTES);
		System.out.println("Int Size in  bits:"+Integer.SIZE);
		System.out.println("Int Size in Bytes:"+Integer.BYTES);
		System.out.println("Character Size:"+Character.SIZE);
		System.out.println("Character Size in Bytes:"+Character.BYTES);
		System.out.println("Float Size:"+Float.SIZE);
		System.out.println("Float Size in Bytes:"+Float.BYTES);
		System.out.println("Double Size:"+Double.SIZE);
		System.out.println("Double Size in Bytes:"+Double.BYTES);
		System.out.println("Long Size:"+Long.SIZE);
		System.out.println("Short Size:"+Short.SIZE);
		System.out.println("Long Size in Bytes:"+Long.BYTES);
		System.out.println("Short Size in Bytes:"+Short.BYTES);
	}
}
