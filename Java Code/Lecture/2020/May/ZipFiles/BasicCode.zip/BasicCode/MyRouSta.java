class Cricket{

	static void batting(){
	System.out.println("Batting...");
	}
	static void bowling(){
	System.out.println("Bowling....");
	}

	static public void main(String args []){
	//Cricket c=new Cricket();
	//c.batting(); Optionally we called
	//c.bowling();
	batting();
	bowling();
	}
}
