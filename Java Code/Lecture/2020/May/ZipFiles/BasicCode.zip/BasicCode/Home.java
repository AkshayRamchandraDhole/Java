class Home{
	void msg(){
	System.out.println("Only Msging");
	}

	public static void main(String args[]){
	Home h=new Home();
	h.msg();
	}

}
