class Home{
	void J1(){
	System.out.println("J1 kr");
	}

	void code(){
	J1();
	System.out.println("Thamb Code krto Pahale");
	}

	public static void main(String args []){
	Home h=new Home();
	h.code();
	
	}

}
