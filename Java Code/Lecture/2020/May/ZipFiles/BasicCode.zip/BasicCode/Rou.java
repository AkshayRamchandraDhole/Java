class Routine{

	void cricket(){
	System.out.println("Playing Cricket..");
	}
	
	public static void main(String args[]){
	System.out.println("Home...");
	Routine r=new Routine();
	r.cricket();
	}
}//optional semicolon ';'
