import java.lang.*;
class Year2020{

	int x=10;

	Year2020(){
	
		System.out.println("In Constructor......");
	}


	public static void main(String args[]){
	
		Year2020 y=new Year2020();
		System.out.println("Danger......");
	}

}
