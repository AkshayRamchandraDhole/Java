class Flat{

	static int tv=1;
	int x=10;

	public static void main(String args[]){
	
		System.out.println("In Main.....");
	}
}
