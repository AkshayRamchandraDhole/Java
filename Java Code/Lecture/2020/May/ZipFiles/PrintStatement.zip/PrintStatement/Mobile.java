public class Mobile{

	void telegram(){
	
		System.out.println("Chatting.......");
	}

	public static void main(String args[]){
		Mobile m=new Mobile();
		m.telegram();
	

	}
}
