public class Home{

	void Zopane(){
	
		System.out.println("Zopane.....");
	}

}
class SweetHome{
	 
	public static void main(String args[]){
	
		System.out.println("SweetHome");
		Home e=new Home();
		e.Zopane();
	}
}
