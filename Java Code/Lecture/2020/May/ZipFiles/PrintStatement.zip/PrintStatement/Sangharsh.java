class Sangharsh{
	
	void player(){
		System.out.println("Players.....");
	}

}
class Match{

	static public void main(String args[]){
	
		System.out.println("Match Ahe aaj");
		Sangharsh s=new Sangharsh();
		s.player();
	}

}
