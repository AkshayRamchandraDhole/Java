class BCCI{

	void niyam(){
	System.out.println("BCCI Rules");
	}
}
class IPL{
	public static void main(String args[]){

	System.out.println("IPL Rules...");
	BCCI b=new BCCI();
	b.niyam();
	}
}
