class Program1{

	public static void main(String args[]){
	
		int num1 = 88, num2 = -20 , res1 = 0 , res2 = 0;
		res1 = num1 << 4;
		System.out.println("Res1="+res1);
		
		res2 = num2 << 3;
		System.out.println("Res2="+res2);

	
	}
}
