class Program2{

	public static void main(String args[]){
	
		int num1 = 75 , num2 = -38 , res1 = 0 , res2 = 0 ;
		
		res1 = num1 >> 2 ;
		System.out.println("Res1="+res1);

		res2 = num2 >> 4 ; 
		System.out.println("Res2="+res2);


		
	}
}
