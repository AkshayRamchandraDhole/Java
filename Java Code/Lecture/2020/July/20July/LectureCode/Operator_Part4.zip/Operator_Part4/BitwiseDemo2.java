class BitwiseRightShift{

	public static void main(String args[]){
	
		int num1 = 95 ;
		int num2 = -95 ;
		int num3 = -125 ;
		int res1 = 0 ;
		int res2 = 0 ;
		int res3 = 0 ;

		res1 = num1 >> 4 ;
		System.out.println("Res1="+res1);
		
		res2 = num2 >> 4 ;
		System.out.println("Res1="+res2);
		
		res3 = num3 >> 5 ;
		System.out.println("Res1="+res3);
	}
}
