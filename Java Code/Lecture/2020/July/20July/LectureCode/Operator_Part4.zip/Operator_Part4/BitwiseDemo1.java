class BitwiseLeftShift{

	public static void main(String args[]){
	
		int x = 12 ;
		int y = 75 ;
		int ans1 = 0 ;
		int ans2 = 0 ;
		ans1 = x << 2 ;
		System.out.println("Ans1="+ans1);
		
		ans2 = y << 4 ;
		System.out.println("Ans2="+ans2);

		int n1 = -12 ; 
		int n2 = -75 ;
		int ans3 = 0 ;
		int ans4 = 0 ;
		

		ans3 = n1 << 2 ;
		System.out.println("Ans3="+ans3);
		
		ans4 = n2 << 4 ;
		System.out.println("Ans3="+ans4);



	}
}
