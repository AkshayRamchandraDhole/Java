class BitwiseUnsignedRightShift{

	public static void main(String args[]){
	
		int num1 = 35 ; 
		int num2 = -35 ;
		int res1 = 0 ;
		int res2 = 0 ;

		res1 = num1>>>4;
		System.out.println("Res1="+res1);

		res2 = num2>>>25;
		System.out.println("Res2="+res2);

	}
}
