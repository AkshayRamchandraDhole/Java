// Unary Operator

class IfUnary{

	public static void main(String args[]){
	
		int x = 10 ;
		
		//Scenario 1 


		if(++x <= 10)
			System.out.println("If Excute....");
		
	/*	//Scenario 2 
		
		//if(x++ <= 10)
		//	System.out.println("If Excute....");
		
		//Scenario 3 
		//if(--x <= 10)
		//	System.out.println("If Excute....");
		
		//Scenaro 4

		if(x-- <= 10)
			System.out.println("If Excute....");
	*/	
		System.out.println("Out of If...");

	}
}
