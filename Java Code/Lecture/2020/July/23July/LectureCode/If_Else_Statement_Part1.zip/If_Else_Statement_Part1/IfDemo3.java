// Logical Operator

class IfLogical{

	public static void main(String args[]){
	
	//	int x = 10 ;
	//	int y = 11 ;
	
		boolean x = true ;
		boolean x1 = false ;
		boolean y = false ;
		boolean y1 = true ;

		
		//Scenario 1 


		if(x && y)
			System.out.println("If Excute....");
		
/*		//Scenario 2 
		
		if(x1 && y1)
			System.out.println("If Excute....");
		
		//Scenario 3 
		
		if(x1 && x)
			System.out.println("If Excute....");
		
		//Scenaro 4

		if(x && y1)
			System.out.println("If Excute....");
*/		
		System.out.println("Out of If...");

	}
}
