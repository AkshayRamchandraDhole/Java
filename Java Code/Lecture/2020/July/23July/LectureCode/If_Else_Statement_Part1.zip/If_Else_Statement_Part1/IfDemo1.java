class IfDemo1{

	public static void main(String args[]){
	
		int x = 10 ;
		int y = 20 ;
		
		// Scenario 1


		if(x < y){
		
			System.out.println("X is Smaller...");
		}

		// Scenario 2 
/*
		if(x > y){
			

			System.out.println("X is Greater...");
		}

		// Scenario 3 

		if(y > x){
		

			System.out.println("Y is Greater...");
		}

		// Scenario 4 

		if(y < x){
		

			System.out.println("Y is Smaller....");
		}	

*/
			System.out.println("Out of If...");
	}
}
