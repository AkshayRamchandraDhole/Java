class Program3{

	public static void main(String args[]){
	
		int ans,a=10,b=20,c=50;
		ans = a++ + ++b + ++c;
		System.out.println(ans);	//82
	}
}
