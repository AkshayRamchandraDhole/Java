class AssigmentOperator{

        public static void main(String args[]){

                int age = 23;
                System.out.println("Age="+age);
        }
}

