class BitwiseAND{

	public static void main(String args[]){
	
		int x = 9 ;
		int y = 10 ;
		int ans = 0 ;
		ans = x & y ;
		System.out.println("Ans="+ans); // 8
	}
}
