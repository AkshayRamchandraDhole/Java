
/*	Identifier :- Nisarg,String,System,println,main
 *
 *	Keywords :- class,public,static,void 
 *
 * */

class Nisarg{

	public static void main(String args[]){
	
		System.out.println("ChakariVadal....");
	}
}
