class ObjectPrint{

	public static void main(String args[]){
	
		ObjectPrint p=new ObjectPrint();
		System.out.println(p);
		System.out.println("Akshay");
	}
}
