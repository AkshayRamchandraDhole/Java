class BooleanDemo{

	public static void main(String args[]){
	
	/*	boolean b;
		System.out.println(b);
		
		 error: variable b might not have been initialized
	*/
	/*	boolean b=0;
		System.out.println(b);

		error: incompatible types: int cannot be converted to boolean
	*/
		boolean b=true;
		System.out.println(b); // true

		boolean f=false;
		System.out.println(f);
	}
}
