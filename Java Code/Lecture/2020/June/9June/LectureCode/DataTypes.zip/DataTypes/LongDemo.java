//Long Range:
//		-9223372036854775808 to  +9223372036854775807
class LongDemo{

	public static void main(String args[]){
	
		/* long l;
		System.out.println(l);

		error: variable l might not have been initialized
*/
		long l=384374;
		System.out.println(l);
	}

}
