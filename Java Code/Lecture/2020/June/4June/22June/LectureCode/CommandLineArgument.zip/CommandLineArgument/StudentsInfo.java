class StudentsInfo{
	
	int CS_Student1=50;
	int CS_Student2=30;

	public static void main(String args[]){
	
		StudentsInfo s=new StudentsInfo();
		System.out.println(s.CS_Student1);
		System.out.println(s.CS_Student2);


	}
}
