class MobileName{

	public static void main(String []mob){
	
		System.out.println(mob);
		System.out.println(mob[0]);
		System.out.println(mob[1]);
		System.out.println(mob[2]);
		System.out.println(mob[3]);
	}
}
