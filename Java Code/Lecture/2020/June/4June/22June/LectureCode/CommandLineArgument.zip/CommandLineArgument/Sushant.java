class Sush{

	public static void main(String movies[]){

		System.out.println(movies);// Print address [Ljava.lang.String;@4aa298b7

		System.out.println(movies[0]);
		System.out.println(movies[1]);
		System.out.println(movies[2]);
		System.out.println(movies[3]);


	}
}
