class Akshay{  

	int age=22;

	void work(){
	
		System.out.println("Lecture Coding...");
	}

	public static void main(String args[]){
	
		Akshay a = new Akshay();
		a.work();
	}
}

