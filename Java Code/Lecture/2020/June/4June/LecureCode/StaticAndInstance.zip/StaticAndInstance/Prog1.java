class NarendraModi{   // NarendraModi = identifier

	int age=70;   // age = identifier

	void work(){   // work = identifier
	
		System.out.println("Vikas...");  // System,out,println  = identifier
	}

	public static void main(String args[]){
	
		NarendraModi n= new NarendraModi();
		n.work();
	}

}

class narendraModi{

}

