class SizeDemo{

	public static void main(String args[]){
	
		System.out.println("Byte="+Byte.SIZE/8+" in bytes");
		System.out.println("Short="+Short.SIZE/8+" in bytes");
		System.out.println("Int="+Integer.SIZE/8+" in bytes");
		System.out.println("Long="+Long.SIZE/8+" in bytes");
		System.out.println("Float="+Float.SIZE/8+" in bytes");
		System.out.println("Double="+Double.SIZE/8+" in bytes");
		System.out.println("Character="+Character.SIZE/8+" in bytes");

	//	System.out.println("Boolean="+Boolean.SIZE/8+" in bytes");   error: cannot find symbol

	}
}
