#include<iostream>
int main(int argc,char** argv){

	std::cout<<"Count="<<argc<<std::endl;
	std::cout<<argv[0]<<std::endl;
	std::cout<<argv[1]<<std::endl;
	std::cout<<argv[2]<<std::endl;
	std::cout<<argv[3]<<std::endl;
	
}
