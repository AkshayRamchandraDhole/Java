#include<stdio.h>
void main(int argc,char** argv){

	printf("%d\n",argc);
}
