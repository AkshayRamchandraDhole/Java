#include<stdio.h>
void main(){

	printf("Core2Web\n");
}
