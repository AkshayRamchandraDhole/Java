class Sush{

	public static void main(String []movies){
	
		System.out.println(movies.length);
		System.out.println(movies[0]);
		System.out.println(movies[1]);
		System.out.println(movies[2]);
		System.out.println(movies[3]);
	}
}
