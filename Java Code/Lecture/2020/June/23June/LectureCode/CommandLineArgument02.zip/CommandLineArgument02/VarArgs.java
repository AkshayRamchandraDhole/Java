class ShreeKrishna{

	public static void main(String... nm){
	 
		System.out.println(nm[0]);
		System.out.println(nm[1]);
		System.out.println(nm[2]);
		System.out.println(nm.length);

	}
}
