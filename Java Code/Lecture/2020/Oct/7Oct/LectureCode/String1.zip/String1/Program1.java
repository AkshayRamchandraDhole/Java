class JaggedInternal{

	public static void main(String[] args){
	
		//int[][] arr = {{10,20},{30,40,50},{60,70,80,90}};

		/*int[][] arr = new int[3][];

		arr[0] = new int[]{10,20};
		arr[1] = new int[]{30,40,50};
		arr[2] = new int[]{60,70,80,90};*/

		int[][] arr = {new int[]{10,20},new int[]{30,40,50},new int[]{60,70,80,90}};
	}
}
