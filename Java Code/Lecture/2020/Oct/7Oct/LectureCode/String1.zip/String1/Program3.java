class StringArrayDemo{

	public static void main(String[] args){
	
		//int[] arr1={10.5,20.5,30.5};
		
		//int[] arr1 = {'A','B','C'};

	//	String[] arr2={"Ashish","Rajesh","Rahul","Kanha"};

		/*for(int i=0;i<arr1.length;i++)
			System.out.println((char)arr1[i]);*/

		String s1 = "Core2Web";

		String s2 = new String("Biencaps");

		//String s3 = new String();

		//String s4;
		//s4=new String("Akshay");

		System.out.println(s1);
		System.out.println(s2);

		//System.out.println(s1.toString());
		//System.out.println(s2.toString());


	}
}
