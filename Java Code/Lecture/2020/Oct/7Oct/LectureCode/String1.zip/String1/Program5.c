#include<stdio.h>
void main(){

	int arr1[3]={10.5,20.5,30.5};
	//int arr1[3]={'A','B','C'};
	for(int i=0;i<3;i++)
		printf("%d\n",arr1[i]);
}
