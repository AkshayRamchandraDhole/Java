public class IPL{

	protected IPL(){
	
	}

}
