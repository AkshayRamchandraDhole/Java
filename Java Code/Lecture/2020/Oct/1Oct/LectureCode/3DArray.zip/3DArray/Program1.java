class Program1{

	public static void main(String[] args){
	
		int [][] marr = {{1,2,3},{5},{6,7,8}};
		for(int i=0;i<3;i++){
		
			for(int j=0;j<3;j++){
			
				System.out.print(marr[i][j]+" ");
			}
			System.out.println();
		}

	/*	int[] arr = {1,2,3};
		for(int i=0;i<4;i++){
		
			System.out.println(arr[i]);
		}*/
	}
}
