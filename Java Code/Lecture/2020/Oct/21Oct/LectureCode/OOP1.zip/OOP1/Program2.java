class PuneCity{

	int x=10;
	String str="Shashi";
	
	PuneCity(){
	
		System.out.println("In no argument Constructor");

	}

	public static void main(String[] args){
	
		PuneCity obj = new PuneCity();
	}
}
