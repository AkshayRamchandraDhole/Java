class StringDemo2{

	public static void main(String[] args){
	
		char[] nm = {'A','k','s','h','a','y'};
		String s1 = new String(nm);
		System.out.println(s1);
		
		byte[] barr = {100,101,102,103,104};
		String s2 = new String(barr);
		System.out.println(s2);
	}
}
