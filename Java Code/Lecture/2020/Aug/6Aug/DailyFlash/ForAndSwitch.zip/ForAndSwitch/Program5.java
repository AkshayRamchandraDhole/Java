class Program5{

	public static void main(String args[]){
		for(int i=1;i<=10;i++){
			int iNum = 1 ;
			iNum = i*3;
			System.out.println("Table of 3 :"+iNum);
			if(iNum%2==0){
			
				System.out.println("In Table "+iNum+" is Even");
			}
		}
	}
}
