class Program10{

	public static void main(String args[]){
	
		int num=10,pow=4,mul=1;
		for(int i=1;i<=4;i++)
			mul=mul*num;
		System.out.println(num+" to the power of "+pow+" is:"+mul);
	}
}
