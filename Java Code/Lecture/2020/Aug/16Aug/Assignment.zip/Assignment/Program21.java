class Program21{

	public static void main(String args[]){
	
		boolean bVar=true;
		boolean bVar1=false;
		char cVar='S';
		int iVar=0;
		System.out.println(bVar==bVar1?iVar:cVar);

	}
}
