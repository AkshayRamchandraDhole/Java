class AdditionRange{

	public static void main(String args[]){
	
		int sum=0,i=0;
		while(i!=11){
		
			sum=sum+i;
			System.out.println("Sum is:"+sum);
			i++;
			
		}
		System.out.println("Total Sum is:"+sum);
	}
}
