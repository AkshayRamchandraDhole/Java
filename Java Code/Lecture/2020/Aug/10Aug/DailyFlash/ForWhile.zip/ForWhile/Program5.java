class TableOf4{

	public static void main(String args[]){
	
	int iNum = 40;
	while(iNum!=0){
	
		System.out.println("Table of 4 is:"+iNum);
		iNum=iNum-4;
	}
		
	}
}
