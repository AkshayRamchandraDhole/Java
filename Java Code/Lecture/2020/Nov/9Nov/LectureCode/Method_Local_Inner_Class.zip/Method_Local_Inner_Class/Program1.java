class Normal{

	void m1(){
	
		class XYZ{
		
		}
	}
}
