class Outer{

	class Inner{
	
	}
}
