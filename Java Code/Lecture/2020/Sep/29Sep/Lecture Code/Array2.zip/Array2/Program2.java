class ArrayDemo2{

	public static void main(String[] args){
	
		int[] iarr = new int[5];

		float[] farr;
		farr = new  float[4];
		
		char[] carr = new char[3];

		double[] darr = new double[10];

		long[] larr = new long[12];

		byte[] barr = new byte[10];

		short[] sarr = new short[3];

		String[] starr = new String[12];

		System.out.println(iarr.getClass());
		System.out.println(farr.getClass());
		
		System.out.println(carr.getClass());
		System.out.println(darr.getClass());
		
		System.out.println(larr.getClass());
		System.out.println(barr.getClass());
		
		System.out.println(sarr.getClass());
		System.out.println(starr.getClass());
		
	}
}
