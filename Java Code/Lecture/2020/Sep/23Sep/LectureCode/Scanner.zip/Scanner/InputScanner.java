import java.util.*;
class InputScanner{

	public static void main(String args[]){
	
		Scanner sc = new Scanner(System.in);
		
		int x = sc.nextInt();
		char y = sc.next().charAt(0);
		String z = sc.next();
		float a = sc.nextFloat();

		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		System.out.println(a);
	}
}
