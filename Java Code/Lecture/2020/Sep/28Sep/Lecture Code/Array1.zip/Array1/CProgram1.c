#include<stdio.h>
void main(){

	//int carr1[];
	
	//int carr1[5];

	//printf("%d\n",carr1);
	
/*	int carr1 [] = {};
	carr1[0]=10;
	carr1[1]=10;
	carr1[2]=10;
	carr1[3]=10;
	carr1[4]=10;  */

	int carr1[] = {10,20,30,40,50};

	for(int i=0;i<5;i++)
		printf("%d\n",carr1[i]);

}
