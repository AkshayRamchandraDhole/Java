interface X{

	void m1();
	/*public static void main(String[] args){
	
		System.out.println("Interfae");
	}*/
}
class Y implements X {

	public void m1(){
	
	}

}
/*interface X{

}
class Y implements X{

}*/
