import java.io.*;
class ThrowsDemo {

	ThrowsDemo() throws ArithmeticException{
	
	}

	public static void main(String[] args) throws IOException{
	
	}
	static throws NullPointerException{
	

	}
}
