class MyException extends Exception{

}
class ThrowsDemo{

	public static void main(String[] args) throws MyException,ArithmeticException{
	
	}
}
