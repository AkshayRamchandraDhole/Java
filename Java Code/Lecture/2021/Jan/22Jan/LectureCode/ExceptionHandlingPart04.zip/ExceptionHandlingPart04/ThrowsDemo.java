import java.io.*;
class ThrowsDemo{

	public static void main(String[] args) throws NullPointerException,ArithmeticException{
	
		System.out.println("Hello");
		System.out.println(10/0);
	}
}
