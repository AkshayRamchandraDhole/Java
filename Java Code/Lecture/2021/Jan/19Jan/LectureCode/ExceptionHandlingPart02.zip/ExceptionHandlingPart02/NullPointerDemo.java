class NullPointerDemo{

	void fun(){
	
		System.out.println("In fun()");
	}
	public static void main(String[] args){
	
		NullPointerDemo c = null;
		c.fun();
	
	}
}
