class ArithmeticDemo{

	public static void main(String[] args){
	
		System.out.println("Exception Demo");
		System.out.println(10/0);
	}
}
