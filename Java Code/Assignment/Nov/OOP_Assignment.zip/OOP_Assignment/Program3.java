class Ant{

}
class Colony{

	public static void main(String[] args){
	Ant[] arr = new Ant[5];
	
	for(int i=0;i<5;i++){
		arr[i] = new Ant();
		System.out.println(arr[i]);
	}
	}
}
