import java.util.*;
class CursorDemo2{

	public static void main(String[] args){

		Vector v = new Vector();
		v.addElement(10);
		v.addElement(20);
		v.addElement(30);
		v.addElement(40);
		v.addElement(50);
		
	//	for(int i=0;i<5;i++)
		System.out.println(v);
	}

}
