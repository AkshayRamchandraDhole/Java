import java.util.*;
class CursorDemo1{

	public static void main(String[] args){

		ArrayList<String> a = new ArrayList<String>();
		
		a.add("Sinhgad");
		a.add("JSPM");
		a.add("Zeal");
		//a.add(1000);
			System.out.println(a);
		
	}


}
